package projet.spring.FindMyTravel.entities;

public enum Status {
draft,activated,deleted
}
