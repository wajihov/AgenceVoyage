package projet.spring.FindMyTravel.entities;

public enum Role {

	client,company,admin
}
