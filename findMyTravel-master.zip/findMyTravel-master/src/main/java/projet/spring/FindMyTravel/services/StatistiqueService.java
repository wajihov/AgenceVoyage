package projet.spring.FindMyTravel.services;

import java.util.ArrayList;

import org.springframework.boot.configurationprocessor.json.JSONObject;

public interface StatistiqueService {

	String getAllStat();
}
