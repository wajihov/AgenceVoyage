package projet.spring.FindMyTravel.entities;

import javax.persistence.Entity;

@Entity
public class Admin extends User{
	public Admin() {
		super();
	}
	
}
