import { SearchCompanyPipe } from './search-company.pipe';

describe('SearchCompanyPipe', () => {
  it('create an instance', () => {
    const pipe = new SearchCompanyPipe();
    expect(pipe).toBeTruthy();
  });
});
